package VariablesCompartidas;

public class TiempoMedio {
    double tiempoMedio = 0;

    public double getTiempoMedio() {
        return tiempoMedio;
    }

    public void setTiempoMedio(double tiempoMedio) {
        this.tiempoMedio = tiempoMedio;
    }
}
